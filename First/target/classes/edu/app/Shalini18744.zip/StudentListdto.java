package edu.app;

public class StudentListdto {
	private int rollNumber;
	private String name;
	private static final String collegeName="VIT";
	private String departMent;
	private static int stufees;
	private int currentfees;
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartMent() {
		return departMent;
	}
	public void setDepartMent(String departMent) {
		this.departMent = departMent;
	}
	public static int getStufees() {
		return stufees;
	}
	public static void setStufees(int stufees) {
		StudentListdto.stufees = stufees;
	}
	public int getCurrentfees() {
		return currentfees;
	}
	public void setCurrentfees(int currentfees) {
		this.currentfees = currentfees;
	}
	public static String getCollegename() {
		return collegeName;
	}
}