package edu.app;

public class FeesUpdate {
	public void amount(StudentListdto fee)
	{
		int add= fee.getRollNumber()+fee.getCurrentfees()+fee.getStufees();
	    String add1=fee.getName()+fee.getDepartMent();
	    
	    }

}
  